﻿using System.Net.NetworkInformation;

namespace CSCPingApp.Services
{
    public class PingService
    {
        public async Task<(string Status, string RoundTripTime)> PingAddressAsync(string ipAddress)
        {
            return await Task.Run(() =>
            {
                Ping ping = new Ping();
                try
                {
                    PingReply reply = ping.Send(ipAddress);
                    if (reply.Status == IPStatus.Success)
                    {
                        return ("Online", $"{reply.RoundtripTime} ms");
                    }
                    else
                    {
                        return ("Offline", "N/A");
                    }
                }
                catch
                {
                    return ("Error", "N/A");
                }
            });
        }
    }
}
